package org.bouncycastle2.bcpg;

/**
 */
public class Packet
    implements PacketTags
{

}
