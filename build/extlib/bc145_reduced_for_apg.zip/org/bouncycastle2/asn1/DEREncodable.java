package org.bouncycastle2.asn1;

public interface DEREncodable
{
    public DERObject getDERObject();
}
