package org.bouncycastle2.jce.interfaces;

import org.bouncycastle2.jce.spec.ElGamalParameterSpec;

public interface ElGamalKey
{
    public ElGamalParameterSpec getParameters();
}
