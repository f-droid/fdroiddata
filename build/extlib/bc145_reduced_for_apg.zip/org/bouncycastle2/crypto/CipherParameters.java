package org.bouncycastle2.crypto;

/**
 * all parameter classes implement this.
 */
public interface CipherParameters
{
}
