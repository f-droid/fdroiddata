package org.bouncycastle2.crypto;

/**
 * Parameters for key/byte stream derivation classes
 */
public interface DerivationParameters
{
}
