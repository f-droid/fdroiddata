/*
 *
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * Version 3, 29 June 2007 *
 * 
 * http://www.gnu.org/licenses/lgpl.html
 * 
 * @Copyright 2010, 2011 M.Beauvais
 * 
 */
package com.measureplace;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Hashtable;

/***
 * MeasurePlaceClient encapsulates all the functionality necessary to upload raw files to the MeasurePlace server. <br>
 * <br>
 * <br>
 * Examples<br>
 * -------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br>
 * import com.measureplace.MeasurePlaceClient;<br>
 * import com.measureplace.InputTypes;<br>
 * <br>
 * // Uploading a cellular log file to the server <br>
 * MeasurePlaceClient.uploadLogFiles(InputTypes.CELLULAR, "c:\\V2_262_log20101225121001-cellular.xml", login, password); <br>
 * <br>
 * // Uploading a wifi log file to the server <br>
 * MeasurePlaceClient.uploadLogFiles(InputTypes.WIFI, "/home/user1/V1_log20101225135201-wifi.xml", login, password); <br>
 * -------------------------------------------------------------------------------------------------------------------------------------------------------------------------<br>
 *  <br>
 *  The formats of cellular and wifi xml files are available on the wiki at the following addresses: <br>
 *  <ul>
 *  <li>Cellular: <a href="http://sourceforge.net/apps/mediawiki/myposition/index.php?title=Log_format">http://sourceforge.net/apps/mediawiki/myposition/index.php?title=Log_format</a><br></li>
 *  <li>Wifi: <a href="http://sourceforge.net/apps/mediawiki/myposition/index.php?title=Wifi_log_format">http://sourceforge.net/apps/mediawiki/myposition/index.php?title=Wifi_log_format</a><br></li>
 *  </ul>
 *  <br>
 *  login and password are set at 
 *  <a href="http://openbmap.org/register.php5">http://openbmap.org/register.php5</a><br>
 *  
 *
 */
public class MeasurePlaceClient {

	private final static String pathCellularQuery = "/upload/upl.php5";
	private final static String hostCellularQuery = "upload.measureplace.com";
	private final static String urlCellularString = "http://upload.measureplace.com/upload/upl.php5";

	private final static String pathWifiQuery = "/upload_wifi/upl.php5";
	private final static String hostWifiQuery = "upload.measureplace.com";
	private final static String urlWifiString = "http://upload.measureplace.com/upload_wifi/upl.php5";

	protected static Hashtable<InputTypes, String> MPhostQuery = new Hashtable<InputTypes, String>() {
		private static final long serialVersionUID = 660145948432567403L; 
		{ 
			put(InputTypes.CELLULAR, hostCellularQuery); 
			put(InputTypes.WIFI, hostWifiQuery);
		}
	};		

	protected static Hashtable<InputTypes, String> MPurl = new Hashtable<InputTypes, String>() {
		private static final long serialVersionUID = 660145948432567403L; 
		{ 
			put(InputTypes.CELLULAR, urlCellularString); 
			put(InputTypes.WIFI, urlWifiString);
		}
	};		
	
	protected static Hashtable<InputTypes, String> MPpathQuery = new Hashtable<InputTypes, String>() {
		private static final long serialVersionUID = 660145948432567403L; 
		{ 
			put(InputTypes.CELLULAR, pathCellularQuery); 
			put(InputTypes.WIFI, pathWifiQuery);
		}
	};		
	
    /***
     * Upload a file to the MeasurePlace server.
     * <p>
     * @param it The type of data to be sent
     * @param fullfilename The directory and filename of the file to be uploaded
     * @param login MeasurePlace login
     * @param password MeasurePlace password
     * @return -1 if an error occured
     * 			0 if everything went fine
     * 			1 if wrong password or login
     ***/
	public static int uploadLogFiles(InputTypes it, String fullfilename, String login, String password) {
		return uploadLogFiles(it, null, fullfilename, login, password);
	}
	

	protected static int uploadLogFiles(InputTypes it, String redirectLoc, String existingFullFilename, String login, String password) {
		String pathQuery = MPpathQuery.get(it);
		String hostQuery = MPhostQuery.get(it);
		String urlString = MPurl.get(it);

		System.out.println("uploadLogFiles - type="+it);
		System.out.println("uploadLogFiles - redirectLoc="+redirectLoc);
		System.out.println("uploadLogFiles - existingFileName="+existingFullFilename);

		try {
			if (redirectLoc!=null) {
				urlString = redirectLoc;
				URL aURL = new URL(urlString);
				hostQuery = aURL.getHost();

			}


			System.out.println("uploadLogFiles - hostQuery="+hostQuery);
			System.out.println("uploadLogFiles - urlString="+urlString);

			System.out.println("uploadLogFiles in");

			HttpURLConnection conn = null;
			DataOutputStream dos = null;
			DataInputStream inStream = null;

			File logFile = new File(existingFullFilename);
			String filename = logFile.getName();

			String lineEnd = "\r\n";
			String twoHyphens = "--";
			String boundary =  "---------------------------"+Long.toString(System.currentTimeMillis(), 16);

			int bytesRead, bytesAvailable, bufferSize;

			byte[] buffer;

			int maxBufferSize = 1*1024*1024;


			try
			{
				String PostData = twoHyphens + boundary + lineEnd;
				PostData +="Content-Disposition: form-data; name=\"openBmap_login\"" + lineEnd +	lineEnd + login + lineEnd;
				//PostData +=lineEnd;
				PostData +=twoHyphens + boundary + lineEnd;
				PostData +="Content-Disposition: form-data; name=\"openBmap_passwd\"" + lineEnd + lineEnd + password + lineEnd;
				//PostData +=lineEnd;		
				PostData +=twoHyphens + boundary + lineEnd;
				PostData +="Content-Disposition: form-data; name=\"file\";"	+ " filename=\""+filename+"\"" + lineEnd + "Content-Type: text/xml"+ lineEnd;
				PostData +=lineEnd;	

				// create a buffer of maximum size
				String FileData = "";
				FileInputStream fileInputStream = new FileInputStream( new File(existingFullFilename) );
				bytesAvailable = fileInputStream.available();
				bufferSize = Math.min(bytesAvailable, maxBufferSize);
				buffer = new byte[bufferSize];

				// read file and write it into form...
				bytesRead = fileInputStream.read(buffer, 0, bufferSize);
				while (bytesRead > 0)
				{
					FileData += new String(buffer,0,bufferSize,"UTF-8");
					bytesAvailable = fileInputStream.available();
					bufferSize = Math.min(bytesAvailable, maxBufferSize);
					bytesRead = fileInputStream.read(buffer, 0, bufferSize);
				}
				fileInputStream.close();
				PostData +=FileData;


				PostData +=lineEnd;	
				PostData +=twoHyphens + boundary + twoHyphens;

				String lengt = new Integer(PostData.length()).toString();

				String contents = "POST " + pathQuery + " HTTP/1.1" + lineEnd +
				"Cache-Control: max-age=259200"+lineEnd +
				"Connection: keep-alive"+lineEnd +
				"Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"+lineEnd +
				"Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7"+lineEnd +
				"Accept-Encoding: gzip,deflate"+lineEnd +
				"Accept-Language: fr,fr-fr;q=0.8,en-us;q=0.5,en;q=0.3"+lineEnd +
				"Host: " + hostQuery +lineEnd +
				"User-Agent: Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.8.1.4) Gecko/20070515 Firefox/2.0.0.4"+lineEnd +
				"Content-Length: "+lengt+lineEnd +
				"Content-Type: multipart/form-data; boundary="+boundary+lineEnd+
				"Keep-Alive: 300"+lineEnd;


				// open a URL connection to the Servlet 
				URL url = new URL(urlString);	
				conn = (HttpURLConnection) url.openConnection();

				// several settings
				conn.setDoOutput(true);
				conn.setDoInput(true);
				conn.setUseCaches(false);
				conn.setDefaultUseCaches(false);
				//conn.setFollowRedirects(false);
				HttpURLConnection.setFollowRedirects(false);
				conn.setInstanceFollowRedirects(false);

				conn.setRequestProperty("Accept", "*/*");
				conn.setRequestProperty("Content-Type", "multipart/form-data; boundary="+boundary);
				conn.setRequestProperty("Connection", "Keep-Alive");
				conn.setRequestProperty("Cache-Control", "no-cache");

				dos = new DataOutputStream( conn.getOutputStream() );
				dos.writeBytes(contents+PostData);
				dos.flush();

				// get response
				inStream = new DataInputStream ( conn.getInputStream() );

				int loc = conn.getResponseCode();//.getHeaderField("Location");
				System.out.println("+++++++++++++++++++++++++++" + loc);

				if (loc == 301)
				{

					String locc = conn.getHeaderField("Location");
					System.out.println("redirect performed" + locc);


					// close streams
					dos.close();
					inStream.close();
					/*
					aFileWriter.write("\nredirection: "+locc);
					aFileWriter.flush();
					aFileWriter.close();
					 */
					return uploadLogFiles(it, locc, existingFullFilename, login, password);

				}else{

					//------------------ read the SERVER RESPONSE
					String str;
					String results="";
					while (( str = inStream.readLine()) != null)
					{
						//System.out.println("Server response is: "+str+"\n");

						results+=str;
					}
					System.out.println("Server response is: "+results+"\n");
					/*
					aFileWriter.write("\nServer response is: "+results);
					aFileWriter.flush();
					aFileWriter.close();
					 */
					// close streams
					dos.close();
					inStream.close();
					
					if (results!=null){
						if (results.toLowerCase().indexOf("wrong login or password")!=-1) {
							return 1;
						}
					}

				}

			}
			catch (MalformedURLException ex)
			{
				ex.printStackTrace();
				return -1;
			}
			catch (IOException ioex)
			{
				ioex.printStackTrace();
				return -1;
			}
		}catch(Exception e) {
			e.printStackTrace();
			return -1;
		}
		return 0;
	}
	
	
	
	public static void main(String argv[]) {
		String login = argv[0];
		String password = argv[1];
		int hello = MeasurePlaceClient.uploadLogFiles(InputTypes.CELLULAR, "c:\\V2_262_log20101225121001-cellular.xml", login, password);
		System.out.println("hello= " + hello);
	}
}
