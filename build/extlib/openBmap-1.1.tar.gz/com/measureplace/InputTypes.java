/*
 *
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * Version 3, 29 June 2007 *
 * 
 * http://www.gnu.org/licenses/lgpl.html
 * 
 * @Copyright 2010, 2011 M.Beauvais
 * @author M.Beauvais
 * @version $Revision: $
 * 
 */

/***
 *
 * Enumeration of communicating objects today handled by the server
 *  
 * @author M.Beauvais
 *
 */
package com.measureplace;

public enum InputTypes {
	CELLULAR, WIFI
}

